package uy.com.geotac.intentmod2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.TextView;

public class InentMod2Detalles extends AppCompatActivity {
    TextView tvNombre;
    TextView tvCelu;
    TextView tvEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inent_mod2_detalles);
        Bundle params=getIntent().getExtras();
        String nombre=params.getString("Nombre");
        String celu=params.getString("Celular");
        String email=params.getString("email");

         tvNombre= (TextView) findViewById(R.id.txNom);
          tvCelu= (TextView) findViewById(R.id.txCel);
          tvEmail= (TextView) findViewById(R.id.txEmail);
        tvNombre.setText(nombre);
        tvCelu.setText(celu);
        tvEmail.setText(email);
    }
    public void llamar(View v){
        String tel=tvCelu.getText().toString();
        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE)!= PackageManager.GET_PERMISSIONS)
            return;
        startActivity(new Intent(Intent.ACTION_CALL, Uri.parse("tel:"+tel)));
    }
    @SuppressLint("IntentReset")
    public void enviarEmail(View v){
        String email=tvEmail.getText().toString();
        Intent eIntent=new Intent(Intent.ACTION_SEND);
        eIntent.setData(Uri.parse("mailto:"));
        eIntent.setType("message/rfc822");

        eIntent.putExtra(Intent.EXTRA_EMAIL, email);
        startActivity(Intent.createChooser(eIntent,"Email "));
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event){

        if (keyCode == KeyEvent.KEYCODE_BACK) {
            Intent i= new Intent(this, MainActivity.class);
            startActivity(i);

        }
        return super.onKeyDown(keyCode, event);
    }
}