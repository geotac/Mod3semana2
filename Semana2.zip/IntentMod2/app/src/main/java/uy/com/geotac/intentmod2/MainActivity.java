package uy.com.geotac.intentmod2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.ArrayAdapter;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ArrayList <Contacto> contactos;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        contactos=new ArrayList<Contacto>();
        contactos.add(new Contacto("Edu","12546233", "edfgm@dfsd.sdf"));
        contactos.add(new Contacto("Esfdu","154233", "sdfgem@dfsd.sdf"));
        contactos.add(new Contacto("Edsfgu","23451233", "esdfbm@dfsd.sdf"));
        contactos.add(new Contacto("Efgdu","1233245", "esdfgm@dfsd.sdf"));
        contactos.add(new Contacto("Edsfgu","145233", "emsdfg@dfsd.sdf"));
        ArrayList<String> nomContactos= new ArrayList();
        for (Contacto c : contactos){
            nomContactos.add(c.getNombre());
        }
        ListView lstContactos = (ListView) findViewById(R.id.lstPpal);
        lstContactos.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, nomContactos));
        lstContactos.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent i = new Intent(MainActivity.this, InentMod2Detalles.class);
                i.putExtra("Nombre",contactos.get(position).getNombre());
                i.putExtra("Celular",contactos.get(position).getCelular());
                i.putExtra("email",contactos.get(position).getEmail());
                startActivity(i);
                finish();
            }
        });

    }
}