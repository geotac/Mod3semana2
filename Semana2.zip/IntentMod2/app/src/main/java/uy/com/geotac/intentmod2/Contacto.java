package uy.com.geotac.intentmod2;

public class Contacto {
    private String nombre;
    private String celular;
    private String email;

    public Contacto(String nombre, String celular, String email) {
        this.nombre = nombre;
        this.celular = celular;
        this.email = email;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

}
